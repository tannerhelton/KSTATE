
public class HelloWorld {
	System.out.println("Test");
}
